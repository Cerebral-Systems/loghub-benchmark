# Devin Loghub Repro Final

Created: 20260530T051302Z

This bundle excludes credentials and /root/.env.

It contains the active Devin Harbor adapter, run wrappers, remaining-task manifests, and Harbor artifacts for both Devin jobs. Merged score is recorded in SUMMARY.json.
